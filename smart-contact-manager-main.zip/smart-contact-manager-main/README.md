# smart-contact-manager
Creating smart contact manager application using springboot, spring MVC, data-jpa, MySQL, spring security, validation, Devtools
