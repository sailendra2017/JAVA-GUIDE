package com.pmz.simplebankingapp.domain.enums;

public enum Currency {
    DOLLAR, EURO, POUND
}
