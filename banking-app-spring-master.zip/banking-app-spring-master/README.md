### Simple Banking Application

Simple Banking Application using Spring Boot, Spring Security, Thymeleaf, MySQL Database

