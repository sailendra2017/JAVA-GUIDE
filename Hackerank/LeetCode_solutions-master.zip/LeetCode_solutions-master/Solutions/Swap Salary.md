### MySQL Solution

```sql
UPDATE salary
SET sex = IF(sex = 'm', 'f', 'm');
```

### Links

- [github.com/RodneyShag](https://github.com/RodneyShag)
