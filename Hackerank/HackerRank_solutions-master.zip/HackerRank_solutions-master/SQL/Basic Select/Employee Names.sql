-- github.com/RodneyShag

SELECT name FROM Employee
ORDER BY name;
