-- github.com/RodneyShag

SELECT CITY, STATE FROM STATION;
