-- github.com/RodneyShag

SELECT * FROM CITY
WHERE ID = 1661;
