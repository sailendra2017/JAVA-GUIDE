-- github.com/RodneyShag

SELECT * FROM CITY;
