-- github.com/RodneyShag

SELECT * FROM CITY
WHERE COUNTRYCODE = 'JPN';
