// github.com/RodneyShag

package _5_8_Draw_Line;

public class Tester {
    public static void main(String[] args) {
        // Code is same as book's code, so no testing is needed
    }
}
