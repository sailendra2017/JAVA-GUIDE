// github.com/RodneyShag

package _7_01_Deck_of_Cards;

public enum Rank {
    TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, 
    JACK, QUEEN, KING, ACE
}
