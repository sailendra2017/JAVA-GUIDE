// github.com/RodneyShag

package _7_01_Deck_of_Cards;

public enum Suit {
    SPADE, CLUB, DIAMOND, HEART
}
