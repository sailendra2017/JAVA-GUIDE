// github.com/RodneyShag

package _7_01_Deck_of_Cards;

public class BlackjackHand extends Hand<BlackjackCard> { // tricky Syntax
    public boolean isBusted() {
        return true; // unimplemented
    }

    public boolean isBlackjack() {
        return true; // unimplemented
    }
    // see book for more methods.
}
