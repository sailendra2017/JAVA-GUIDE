// github.com/RodneyShag

package introduction;

public class Tester {
    public static void main(String[] args) {
        System.out.println("*** Test print pairs\n");
        ABCD.printPairs();
    }
}
