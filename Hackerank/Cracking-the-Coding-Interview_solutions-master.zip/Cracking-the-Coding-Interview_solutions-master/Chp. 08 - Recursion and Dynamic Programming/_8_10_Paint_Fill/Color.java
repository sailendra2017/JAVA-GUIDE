// github.com/RodneyShag

package _8_10_Paint_Fill;

public enum Color {
    BLACK, WHITE, RED, YELLOW, GREEN
}
