// github.com/RodneyShag

package _17_08_Circus_Tower;

public class Tester {
    public static void main(String[] args) {
        System.out.println("*** Test 8.13: Stack of Boxes\n");
        int result = CircusTower.findMax(new int[][]{{2, 3}, {3, 3}, {4,3}, {5, 5}});
        System.out.println(result);
    }
}
